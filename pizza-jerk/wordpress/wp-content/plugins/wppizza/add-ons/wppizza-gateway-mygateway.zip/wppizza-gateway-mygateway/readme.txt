=== WPPizza Gateway Mygateway Payments===
Contributors: ollybach
Plugin URI: https://www.wp-pizza.com
Author URI: https://www.wp-pizza.com
Tags: mygateway payments, mygateway , gateway, wppizza
Requires at least: PHP 5.3+, WP 3.3 , WPPizza 2.11.8.14+
Tested up to: 4.2.2
Stable tag: 1.0


WPPizza Gateway - Mygateway Payments Gateway  for WPPizza - Requires WPPIZZA 2.11.8.14+

== Description ==

WPPizza Gateway - Mygateway Payments Gateway for WPPizza - Enables Mygateway Payments for orders using the Wordpress WPPIZZA Plugin - Requires WPPIZZA 2.11.8.14+

== Changelog ==

 
1.0  
* Initial Release  
10th June 2015  

