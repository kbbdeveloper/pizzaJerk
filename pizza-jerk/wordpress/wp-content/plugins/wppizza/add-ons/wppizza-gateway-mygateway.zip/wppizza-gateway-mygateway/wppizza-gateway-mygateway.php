<?php
/*
Plugin Name: WPPizza Gateway - Mygateway (HPP)
Description: Mygateway Payments Gateway using Hosted Payment Pages for WPPizza (adjust settings in WPPizza->Gateways) - Requires WPPIZZA 2.11.8.14+
Author: ollybach
Plugin URI: https://www.wp-pizza.com
Author URI: https://www.wp-pizza.com
Version: 1.0

Copyright (c) 2015, Oliver Bach
All rights reserved.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**ini plugin**/
add_action( 'init', 'wppizza_gateway_mygateway');
/*on uninstall, remove options from table*/
register_uninstall_hook( __FILE__, 'wppizza_gateway_mygateway_uninstall');

function wppizza_gateway_mygateway(){
	if (!class_exists( 'WPPizza' ) ) {return;}

		class WPPIZZA_GATEWAY_MYGATEWAY extends WPPIZZA_GATEWAYS {
			/***********************************************
			*
			*	[constructor]
			*
			**********************************************/
			function __construct() {
				/**********************************
					general setup
				**********************************/
				parent::__construct();
				$this->gatewayVersion = '1.0';/*current vesrion number of this gateway required*/
				$this->gatewayName = 'Mygateway';/*required*/
				$this->gatewayIdent = 'mygateway';/*required, must be unique for each gateway a-z 0-9 and underscores only please. no spaces, dots, hyphens etc*/
				$this->gatewayMinWppizzaVersion = '2.15';/*required - 2.11.8.14+ will probably also work*/
				$this->gatewaySelect = substr(strtolower(get_class()),16);/**to identify which gateway send us back to the main site**/
				$this->gatewayDescription = '';/*required but can be empty*/
				$this->gatewaySurchargePercent = 'GwSurchargePc';/*required - set field name that corresponds to surcharges in percent so it can also be calculated in confirmation page (if used/enabled)*/
				$this->gatewaySurchargeFixed = 'GwSurchargeFixed';/*required - set field name that corresponds to fixed surcharges so it can also be calculated in confirmation page (if used/enabled)*/
				$this->gatewayAdditionalInfo = '';/*required but can be empty*/
				$this->gatewayOptionsName = strtolower(get_class());/*required*/
				$this->gatewayOptions = get_option($this->gatewayOptionsName,0);/*required*/
				$this->gatewayImage = "<img src='".plugins_url( 'images/logo.png' , __FILE__ )."' class='wppizza-gateway-img' id='wppizza-gateway-img-".$this->gatewayIdent."' />";
				$this->gatewayBaseUrl = plugin_dir_url(__FILE__);
				$this->gatewayBasePath = plugin_dir_path(__FILE__);/*required for logging**/


				/**********************************
					set urls
				**********************************/
				$this->live_url		='https://mygateway.live.url';/*gateway live post/get url*/
				$this->test_url		='https://mygateway.test.url';/*gateway test post/get url*/
				$this->notifyUrl	= ''.plugin_dir_url(__FILE__).'ipn/ipn.php';/*gateway notification url*/				

				/**********************************
					load text domain
				**********************************/
				add_action('init', array($this, 'wppizza_gateway_load_plugin_textdomain'));

				/**********************************
					admin
				**********************************/
				if(is_admin()){
					/*check if we have the relevant WPPIZZA version etc**/
					add_action('admin_init', array( $this, 'wppizza_gateway_check_requirements'),11);
					/**install default options or update**/
					add_action('admin_init', array( $this, 'wppizza_gateway_admin_init'),11);

				}
				/**********************************
					frontend
				**********************************/
				if(!is_admin()){
					/**get and check order details and submit to gateway**/
					if(isset($_POST['wppizza_hash']) && isset($_POST['wppizza-gateway']) && $_POST['wppizza-gateway']==$this->gatewaySelect){
						/** 
							note: wpml 3.0+ added an init action with -1000 priority which stops other -1000 actions dead for reasons only they will know. 
							so lets use somthing higher and somewhat arbitrary, which they are unlikely to use . maybe they will even fix it one day
						**/
						add_action('init', array( $this, 'gateway_process_payment') ,$this->gatewayRedirectPriority);
					}
					/**order has been executed, cancelled etc (via gayeway return url) display thank you, cancelled etc as appropriate**/
					if(isset($_GET['wpptx'.$this->gatewayIdent.''])){
						/*clear cart on success*/
						if(isset($_POST['x_response_code']) && $_POST['x_response_code']=='1'){
							add_action('init', array($this,'gateway_unset_cart'),999);
						}
						/*remove all previous content filters first*/
						remove_all_filters('the_content');
						add_filter('the_content', array($this,'gateway_transaction_processed'),998);
					}
				}
			}

		    /*****************************************************
		     * load text domain on init.
		     ******************************************************/
		  	function wppizza_gateway_load_plugin_textdomain(){
		        load_plugin_textdomain('wppizza-gateway-mygateway', false, dirname(plugin_basename( __FILE__ ) ) . '/lang' );
		    }
			/********************************************************************************************************
			*
			*	[set/get gateway options]
			*
			*	key=>"some_key_name"							[required][str]
			*	value=>"some input value defaults"				[required][mixed]
			*	type=>"text"									[required][str][one of these: text/email/checkbox/textarea/select/texteditor==textarea with tinymce]
			*	options=>"<select><option></option></select>"	[required if type=select][str][full select STRING including select name and id]
			*	validateCallback=>"function_name"				[required, but can be left blank][str/array][validation to run on save (if its an array, [0]==function; [1]==additional parameter to pass to function)]
			*	label=>"some label"								[optional, but probably a good idea][str]
			*	descr=>"description for field"					[optional][str]
			*	placeholder=>"placeholder"						[optional][str]
			*	wpml=>boolean									[optional] set if option should be translatable via wpml (only values that return strings will be available). if omitted (or true) values that return strings will be available va wpml string translation
			*
			********************************************************************************************************/
			function gateway_settings($optionsOnly=false) {
				$gwSettings=array();
				$gatewaySettings=array();

				/******************************************************************************

					[gateway specific]

				******************************************************************************/

				$gatewaySettings[]=array(
					'key'=>'X_LOGIN',
					'value'=>empty($this->gatewayOptions['X_LOGIN']) ? '' : $this->gatewayOptions['X_LOGIN'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_string',
					'label'=>__('Payment Page ID','wppizza-gateway-mygateway'),
					'descr'=>'<span style="color:red"> '.__('required','wppizza-gateway-mygateway').'</span> '.__('Payment Page ID located in the Mygateway Gateway Payment Pages administration interface','wppizza-gateway-mygateway'),
					'placeholder'=>'',
					'wpml'=>false
				);
				$gatewaySettings[]=array(
					'key'=>'TRANSACTION_KEY',
					'value'=>empty($this->gatewayOptions['TRANSACTION_KEY']) ? '' : $this->gatewayOptions['TRANSACTION_KEY'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_string',
					'label'=>__('Transaction Key','wppizza-gateway-mygateway'),
					'descr'=>'<span style="color:red"> '.__('required','wppizza-gateway-mygateway').'</span> '.__('located on the Security tab when viewing an individual Mygateway Gateway Payment Page','wppizza-gateway-mygateway'),
					'placeholder'=>__('Transaction Key','wppizza-gateway-mygateway'),
					'wpml'=>false
				);

				/******************************************************************************

					[generic , optional]

				******************************************************************************/
				$gatewaySettings[]=array(
					'key'=>'GwSurchargePc',
					'value'=>empty($this->gatewayOptions['GwSurchargePc']) ? 0 : $this->gatewayOptions['GwSurchargePc'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_float_only',
					'label'=>__('Surcharge (in %) [0 to disable]','wppizza-gateway-mygateway'),
					'descr'=>' '.__('if used, you might want to add something - in additional plugin information perhaps - that says "a x% handling fee will added at checkout" or similar .','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'wpml'=>false
				);
				$gatewaySettings[]=array(
					'key'=>'GwSurchargeFixed',
					'value'=>empty($this->gatewayOptions['GwSurchargeFixed']) ? 0 : $this->gatewayOptions['GwSurchargeFixed'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_float_only',
					'label'=>__('Fixed Surcharge [0 to disable]','wppizza-gateway-mygateway'),
					'descr'=>' '.__('if used, you might want to add something - in additional plugin information perhaps - that says "x amount handling fee added at checkout" or similar .','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'wpml'=>false
				);
				/******************************************************************************

					[generic , recommended]

				******************************************************************************/
				$gatewaySettings[]=array(/**test or live**/
					'key'=>'GwSandbox',
					'value'=>true,
					'type'=>'checkbox',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_boolean',
					'label'=>__('Test Mode ? (Y/N)','wppizza-gateway-mygateway'),
					'descr'=>__('enable to use test mode','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'selected'=>checked($this->gatewayOptions['GwSandbox'],true,false),
					'wpml'=>false
				);
				$gatewaySettings[]=array(/**logging enabled -> dir /logs/ must exist**/
					'key'=>'GwLogging',
					'value'=>false,
					'type'=>'checkbox',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_boolean',
					'label'=>__('Logging ? (Y/N)','wppizza-gateway-mygateway'),
					'descr'=>__('Do you wish to enable logging ? [logfiles are located in /logs/ of this plugin]','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'selected'=>checked($this->gatewayOptions['GwLogging'],true,false),
					'wpml'=>false
				);

				$gatewaySettings[]=array(/**send general errors and possibly fruadulent transaction to admin email**/
					'key'=>'GwSendAdminErrors',
					'value'=>false,
					'type'=>'checkbox',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_boolean',
					'label'=>__('Send non verified transactions to admin email','wppizza-gateway-mygateway'),
					'descr'=>__('It might be a good idea to have all non-verified transactions or other transaction errors sent to your administrators email address to investigate. You can turn this off if you are happy everything works. If you enable logging, all those occurences will be logged regardless.','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'selected'=>checked($this->gatewayOptions['GwSendAdminErrors'],true,false),
					'wpml'=>false
				);

				/******************************************************************************

					[gateway specific]

				******************************************************************************/

				$gatewaySettings[]=array(/**set button image if it is the only gateway enabled**/
					'key'=>'MygatewayButton',
					'value'=>empty($this->gatewayOptions['MygatewayButton']) ? $this->gatewayBaseUrl.'images/button.png' : $this->gatewayOptions['MygatewayButton'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_string',
					'label'=>__('Button Image','wppizza-gateway-mygateway'),
					'descr'=>__('Url of gateway button you would like to use if this the only gateway in use','wppizza-gateway-mygateway').'',
					'placeholder'=>'http://',
					'wpml'=>true
				);
				$gatewaySettings[]=array(
					'key'=>'TRY_AGAIN',
					'value'=>empty($this->gatewayOptions['TRY_AGAIN']) ? ''.__('please click here to try again','wppizza-gateway-mygateway').'' : $this->gatewayOptions['TRY_AGAIN'],
					'type'=>'text',
					'options'=>false,
					'validateCallback'=>'wppizza_validate_string',
					'label'=>__('"Try again" link text','wppizza-gateway-mygateway'),
					'descr'=>''.__('if transactions/payments fail for one reason or another a link will be displayed to to be able to retry the checkout process','wppizza-gateway-mygateway'),
					'placeholder'=>false,
					'wpml'=>false
				);


				/*only get key/value pairs -> when inserting/updating options*/
				if($optionsOnly){
					foreach($gatewaySettings as $k=>$v){
						$gwSettings[$v['key']]=$v['value'];
					}
				}
				/*get whole array -> when displaying/validating options*/
				if(!$optionsOnly){
					$gwSettings=$gatewaySettings;
				}

				return $gwSettings;
			}
			/*****************************************************************
			*	[required: -> version number]
			*	[optionally: other vars that should be stored but not editable
			*****************************************************************/
			function gateway_settings_non_editable(){
				$gatewayOption['version']=$this->gatewayVersion;/**required**/
				return $gatewayOption;
			}
			/******************************************************
			*
			*
			*	[frontend orderpage button and form fields output]
			*
			*
			******************************************************/
			/**generates button , displayed when there's ONLY ONE gateway**/
			/**will print button. if this function is not defined in this gateway class or returns empty, standard button will be used**/
			/**if used, button/input  MUST have class=wppizza-ordernow **/
			function gateway_button(){
				$buttonOutput='';
				$buttonOutput.='<div class="wppizza-button-'.$this->gatewaySelect.'-wrap" style="text-align:center">';
				$buttonOutput.='<input type="image" src="'.$this->gatewayOptions['MygatewayButton'].'" border="0" id="wppizza-button-'.$this->gatewaySelect.'" class="wppizza-button-'.$this->gatewaySelect.' wppizza-ordernow" name="submit" alt="" />';
				$buttonOutput.='</div>';

				return $buttonOutput;
			}

			/*********************************************************************************************************************************
			*
			*
			*	[send vars to gateway to pay at payment page]
			*
			*
			*********************************************************************************************************************************/
			function gateway_process_payment($orderDetails=false,$orderId=false){


				/***************************
					get set options
				*****************************/
				$gatewayOptions=$this->gatewayOptions;

				/**************
					get order details
				**************/
				$order=$this->wppizza_gateway_get_order_details($_POST['wppizza_hash']);
				if(!$order){/**stop right there**/
					print"ERROR: THIS ORDER DOES NOT EXIST";
					exit();
				}
				/********************************************************************************************
				*
				*	[update db entry with POST (customer) vars, updated order vars (surcharges) and set used gateway
				*	returns new/amended order vars , so charged amounts match if adding surcharges etc
				*
				********************************************************************************************/
				$order=$this->wppizza_gateway_update_order_details($order);
				$orderDetails=$order->order_details;

				/****************************************
				*
				*	DUMMY VARS
				*	set and sanitize merchant/order vars
				*	for ease of use
				*
				*****************************************/
				// Timestamp
				$TIMESTAMP = current_time('timestamp', true);
				// merchant id
				$X_LOGIN = $gatewayOptions['X_LOGIN'];
				// order ID
				$ORDER_ID = $order->id;
				// the amount
				$AMOUNT = strval($orderDetails['total']);
				// the currency	- ISO 3 letter
				$CURRENCY = strtoupper($orderDetails['currencyiso']);
				// Shared Secret
				$TRANSACTION_KEY=$gatewayOptions['TRANSACTION_KEY'];
				//sandbox/live ?
				$GATEWAY_URL = !empty($gatewayOptions['GwSandbox']) ? $this->test_url : $this->live_url ;
				//return url back to order page
				$GATEWAY_RETURN_URL = esc_url_raw(add_query_arg(array('wpptx'.$this->gatewayIdent.''=>$order->hash), $this->wppizza_gateway_orderpage()));
				//ipn/notifications by gateway should be send here
				$IPN_URL = $this->notifyUrl ;
				/*****************************************************************
				*
				*	DUMMY VARS
				*	some example/dummy variables to send to gateway, use/change as required
				*
				******************************************************************/
				$gwValues['toGateway']['variable_1']=''.$X_LOGIN.'';
				$gwValues['toGateway']['variable_2']=$TIMESTAMP;
				$gwValues['toGateway']['variable_3']=$AMOUNT;
				$gwValues['toGateway']['variable_4']=''.$CURRENCY.'';
				$gwValues['toGateway']['variable_5']=$ORDER_ID;
				/*
				*
				*
				*
				*
				*
				*
				*	add other variables the gateway requires as needed
				*
				*
				*
				*
				*
				*
				*/

				/********************************************************************************************
				*
				*	[finally,  lets send the whole shebang to the payment processor]
				*
				*********************************************************************************************/
				header('location: '.$GATEWAY_URL.'?'.http_build_query($gwValues['toGateway'],'','&'));
				exit();
			}
			/*********************************************************************************************************************************
			*
			*
			*	[handle gateway response]
			*	-> called from ipn.php
			*
			*********************************************************************************************************************************/
			function gateway_handle_response($gwResponse,$gatewayOptions){

				/******************************************************************************************
					ERROR LOGGING:
					check that we have some sort of RESULT and an ORDER_ID
					otherwise just fail, as we will have no idea what when where.
					should really never happen though unless there has been some serious tampering going on

				*******************************************************************************************/
				if(!isset($gwResponse['mygateway_response_code']) || !isset($gwResponse['mygateway_invoice_num'])){
					/**log**/
					$this->wppizza_gateway_logging($gatewayOptions['GwLogging'], false,  false, 'ERROR - No valid order details or status received: '.PHP_EOL.' Mygateway Response:'.PHP_EOL.print_r($gwResponse,true), 'error');
					exit();
				}

				/***************************************************************************
					ERROR LOGGING:
					[check that we have at least an order with that id , lets get the details if exist]

					NOTE
					mygateway_invoice_num should be equivalent to the id of the order

				***************************************************************************/
				$order=$this->wppizza_gateway_get_order_details(false, $gwResponse['mygateway_invoice_num']);
				if(!$order){/**doesnt exist**/
					/**just log. no need to send these to admin really as its probably just junk sent from somewhere*/
					$this->wppizza_gateway_logging($gatewayOptions['GwLogging'], false, false, 'Order does not exist: '.PHP_EOL.print_r($gwResponse,true), 'error');
					return;
				}


				/***************************************************************************
				*
				*	OK, order exists, some more error checking before executing:
				*
				***************************************************************************/

				/****************************************************
					error of some sort was returned by the gateway if !=1
					1 for “Approved”, 2 for “Declined”, 3 for “Error”
				****************************************************/
				if($gwResponse['mygateway_response_code']!='1'){
					/**logging**/
					$this->wppizza_gateway_logging($gatewayOptions['GwLogging'],  false, $order->id, $gwResponse, 'error');
					/*update db as failed*/
					$this->wppizza_gateway_order_payment_failed($order->id, false, $gwResponse, $gwResponse['mygateway_trans_id']);
					/**send error to admin -> on fail only**/
					$this->wppizza_gateway_send_errors_to_admin($gatewayOptions['GwSendAdminErrors'], false, $order->id, print_r($gwResponse,true));

					exit();
				}

				/****************************************************
					status ok, maybe doublecheck amount, currency etc
					or compare hashes. depends on gateway
				****************************************************/
				if($gwResponse['mygateway_response_code']=='1'){
						/*no errors yet**/
						$tamper=array();

						/**some errors were encountered**/
						if(count($tamper)>0){
							$print='ERROR - TAMPERING ATTEMPT: '.PHP_EOL;
							$print.=implode('',$tamper);
							$print.='mygateway values received: '.print_r($gwResponse,true).PHP_EOL;
							$print.='order values: '.print_r($toHash,true).PHP_EOL;
							/**logging**/
							$this->wppizza_gateway_logging($gatewayOptions['GwLogging'],  false, $order->id, $print , 'error');
							/*update db as failed*/
							$this->wppizza_gateway_order_payment_failed($order->id, false, $gwResponse, $gwResponse['mygateway_trans_id']);
							/**send error to admin**/
							$this->wppizza_gateway_send_errors_to_admin($gatewayOptions['GwSendAdminErrors'], false, $order->id, $print );

							exit();
						}
				}

				/****************************************************
				*	FINALLY: all is well
				*	first set to captured -> complete order (send emails) ->set to complete :
				*	[log, update db to complete, send order emails]
				****************************************************/
				if($gwResponse['mygateway_response_code']=='1'){
					/**logging**/
					$this->wppizza_gateway_logging($gatewayOptions['GwLogging'],  false, $order->id, 'Payment Captured : '.PHP_EOL.print_r($gwResponse,true), 'ok');
					/*update db as captured*/
					$this->wppizza_gateway_order_payment_captured($order->id, false, $gwResponse['mygateway_trans_id'], $gwResponse);
					/**execute order/send emails/update db etc**/
					$this->wppizza_gateway_complete_order($order->id, false, $gatewayOptions['GwLogging'], $gatewayOptions['GwSendAdminErrors']);
					/**logging, all is ok**/
					$this->wppizza_gateway_logging($gatewayOptions['GwLogging'], false, false, 'Payment Complete: '. PHP_EOL . print_r($gwResponse,true), 'ok');

					exit();
				}
			}

			/******************************************************
			*
			*
			*	[returning to site via gatewayReturnUrl ]
			*	display info (order fail reason, whatever)
			*
			******************************************************/
			function gateway_transaction_processed($content){
				/**get status of order**/
				$order=$this->wppizza_gateway_get_order_details($_GET['wpptx'.$this->gatewayIdent.'']);

				if(empty($order)){return;}

				if($order->payment_status!='COMPLETED'){
					/*if not completed there will be transaction errors*/
					$error=$order->transaction_errors;
					$markup="<div class='wppizza-gateway-failed'>";
					$markup.="<h2>".__('Payment failed','wppizza-gateway-mygateway')." : <span style='color:red'>".print_r($error,true)."</span></h2>";
					$markup.="<p><a href='".$this->wppizza_gateway_orderpage()."'>".$this->gatewayOptions['TRY_AGAIN']."</a></p>";
					$markup.="</div>";

					return $markup;
				}
				/*payment successful**/
				if($order->payment_status=='COMPLETED'){
					return $this->wppizza_gateway_order_completed($_GET['wpptx'.$this->gatewayIdent.''], false, '', '', true);
				}
				return $content;
			}
		}
}
?>