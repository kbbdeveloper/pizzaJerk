<?php
/*********************************************************************************************************
*
*
*	Handle Payment Notifications Received from Gateway
*
*
*********************************************************************************************************/
if(count($_POST)==0){/*stop right here when no data was sent**/
	exit();
}

/*********************************
	skip themes stuff
*********************************/
	define('WP_USE_THEMES', false);
/************************************************************************
*	 find path to wp-load to load
*	 WordPress Environment and Template
*************************************************************************/
function get_wp_config_path($file){
    $base = dirname(__FILE__);
    $base = str_replace("\\", "/", $base);/*in case we are on windows**/
    $chunkPath=explode("/",$base);
    /*let's go UP the tree *****/
    for($i=count($chunkPath)-1;$i>=0;$i--){
    	$loadPath=implode('/',$chunkPath);
    	if(file_exists($loadPath."/".$file)){
    		return $loadPath."/".$file;
    	}
    	unset($chunkPath[$i]);
    }
}
$wpLoad=get_wp_config_path('wp-load.php');
require($wpLoad);


/*****************************************************
 instanciate this gateway class
 ****************************************************/
$gw=new WPPIZZA_GATEWAY_MYGATEWAY();


/********************************************************************************
log all access to the ipn
*********************************************************************************/
$gw->wppizza_gateway_logging($gw->gatewayOptions['GwLogging'], false, false,''.print_r($_REQUEST,true), 'ipn-access');/**log all access to ipn. does NOT necessarily constitute any errors**/

/********************************************************
	now handle response if something was sent
*********************************************************/
$gw->gateway_handle_response($_POST, $gw->gatewayOptions);

exit();
?>